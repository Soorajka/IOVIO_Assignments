Pre-Requisite - UFT tool should be available in the machine

1. Download the folder from Github and Place it any drive/Folder
2. Available folders/Files are 
	Assignment2 - Is the Test Driver folder
	Config - Configuration file placed
	FunctionalLibrary - Related Functional Library placed
	ObjectRepository - Related Object repository placed 
	Results - this folder has the test result in Excel format with the steps and details
	Screenshots -This folder has all the screenshots captured as part of the test
	UseCase - Test case is available with Test Scenario sheet and Test Flow sheet
	DoubleClicktoRun.vbs - Scheduler(double click to run the test)
4. Double click on the file "DoubleClicktoRun.vbs"
5. Once the run is ciompleted, you can find the Result and Screenshots in the respective folders.

To run with some other link, Please follow the steps

1.Update the Config file with the changes
<Variable>
 <Name>URL</Name>
 <Value>https://www.kia.com/nl/</Value>
</Variable>
<Variable>
 <Name>Browser_Obj_Name</Name>
 <Value>brw_KIA</Value>
</Variable>
<Variable>
 <Name>Page_Obj_Name</Name>
 <Value>pge_KIA</Value>
</Variable>

2. Browsers are given only IE or GC
3. Object names should be with the proper naming
Link - lnk_ObjName
WebElement - ele_ObjName
WebEdit - edt_ObjName
Image - img_ObjName
WebList - lst_ObjName
WebButton - btn_ObjName
4. Action key words are 
Click
Filltext
Select
countObj_Tagname
Verify_<ObjProperty>

